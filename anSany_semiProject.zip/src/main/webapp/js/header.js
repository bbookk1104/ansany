$(".header-navi>ul>li a").on("mouseover",function(){
    $(".header-top").css("height","401px");
});
$(".header-navi>ul>li a").on("mouseout",function(){
    $(".header-top").css("height","81px");
});

$(".header-navi").on("mouseover",function(){
    $(".header-top").css("height","401px");
});

$(".header-navi").on("mouseout",function(){
    $(".header-top").css("height","81px");
});